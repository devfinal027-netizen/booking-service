const { Pricing } = require('../models/pricing');
const { Booking } = require('../models/bookingModels');
const { emitBookingTargets } = require('../sockets/utils');
const logger = require('../utils/logger');
const metrics = require('../utils/metrics');
const geolib = require('geolib');
const mongoose = require('mongoose');

// Legacy function - maintained for backward compatibility
async function recalcForBooking(bookingId) {
  const booking = await Booking.findById(bookingId);
  if (!booking) {
    const err = new Error('Booking not found');
    err.status = 404;
    throw err;
  }

  const distanceKm = geolib.getDistance(
    { latitude: booking.pickup.latitude, longitude: booking.pickup.longitude },
    { latitude: booking.dropoff.latitude, longitude: booking.dropoff.longitude }
  ) / 1000;

  const p = await Pricing.findOne({ vehicleType: booking.vehicleType, isActive: true }).sort({ updatedAt: -1 });
  if (!p) {
    const err = new Error('Active pricing not found for vehicleType');
    err.status = 404;
    throw err;
  }

  const fareBreakdown = {
    base: p.baseFare,
    distanceCost: distanceKm * p.perKm,
    timeCost: 0,
    waitingCost: 0,
    surgeMultiplier: p.surgeMultiplier,
  };
  const fareEstimated = (fareBreakdown.base + fareBreakdown.distanceCost + fareBreakdown.timeCost + fareBreakdown.waitingCost) * fareBreakdown.surgeMultiplier;

  booking.distanceKm = distanceKm;
  booking.fareEstimated = fareEstimated;
  booking.fareBreakdown = fareBreakdown;
  await booking.save();

  return {
    bookingId: String(booking._id),
    vehicleType: booking.vehicleType,
    pickup: booking.pickup,
    dropoff: booking.dropoff,
    distanceKm,
    fareEstimated,
    fareBreakdown
  };
}

/**
 * Calculate live pricing based on driver's current location during ongoing trip
 * @param {string} bookingId - The booking ID
 * @param {Object} currentLocation - Driver's current location {latitude, longitude}
 * @returns {Object} Updated pricing calculation
 */
async function calculateLivePricing(bookingId, currentLocation) {
  const startedAt = Date.now();
  try {
    logger.info('[PricingService] Starting live pricing calculation:', {
      bookingId,
      currentLocation,
      timestamp: new Date().toISOString()
    });

    const booking = await Booking.findById(bookingId);
    if (!booking) {
      logger.error('[PricingService] Booking not found:', { bookingId });
      throw new Error('Booking not found');
    }

    logger.info('[PricingService] Booking found:', {
      bookingId,
      status: booking.status,
      vehicleType: booking.vehicleType,
      driverId: booking.driverId,
      pickup: booking.pickup
    });

    if (booking.status !== 'ongoing') {
      // Allow live pricing during accepted status as a preview until trip_started flips to ongoing
      if (booking.status !== 'accepted') {
        logger.warn('[PricingService] Invalid booking status for pricing update:', {
          bookingId,
          currentStatus: booking.status,
          requiredStatus: 'ongoing|accepted'
        });
        throw new Error('Pricing updates only available for ongoing or accepted trips');
      }
    }

    // Get admin-set pricing for vehicle type
    logger.info('[PricingService] Looking up pricing for vehicle type:', {
      bookingId,
      vehicleType: booking.vehicleType
    });

    const pricing = await Pricing.findOne({ 
      vehicleType: booking.vehicleType, 
      isActive: true 
    }).sort({ updatedAt: -1 });

    if (!pricing) {
      logger.error('[PricingService] No active pricing found:', {
        bookingId,
        vehicleType: booking.vehicleType
      });
      throw new Error(`No active pricing found for vehicle type: ${booking.vehicleType}`);
    }

    logger.info('[PricingService] Pricing rules found:', {
      bookingId,
      pricingId: pricing._id,
      baseFare: pricing.baseFare,
      perKm: pricing.perKm,
      minimumFare: pricing.minimumFare,
      surgeMultiplier: pricing.surgeMultiplier
    });

    // Calculate distance traveled using TripHistory cumulative path when available; fallback to pickup→current
    let distanceTraveled = 0;
    let movingMinutes = 0;
    let waitingMinutes = 0;

    const now = new Date();
    const canUseTripHistory = (() => {
      try { return mongoose.connection && mongoose.connection.readyState === 1; } catch (_) { return false; }
    })();

    if (canUseTripHistory) {
      let TripHistoryModel = null;
      try { TripHistoryModel = require('../models/bookingModels').TripHistory; } catch (_) {}
      if (!TripHistoryModel) {
        try { TripHistoryModel = require('../models/tripHistoryModel'); } catch (_) {}
      }
      try {
        if (TripHistoryModel && typeof TripHistoryModel.findOne === 'function') {
          const trip = await TripHistoryModel.findOne({ bookingId: booking._id }).select({ locations: 1 }).lean();
          const points = Array.isArray(trip?.locations) ? trip.locations : [];

          // Sum path distance from recorded points
          for (let i = 1; i < points.length; i++) {
            const a = points[i - 1];
            const b = points[i];
            const meters = geolib.getDistance(
              { latitude: Number(a.lat), longitude: Number(a.lng) },
              { latitude: Number(b.lat), longitude: Number(b.lng) }
            );
            if (Number.isFinite(meters) && meters >= 10) {
              distanceTraveled += meters / 1000;
            }
            // Classify time by 10m threshold where timestamps are present
            const at = a.timestamp ? new Date(a.timestamp).getTime() : null;
            const bt = b.timestamp ? new Date(b.timestamp).getTime() : null;
            if (Number.isFinite(at) && Number.isFinite(bt) && bt > at) {
              const minutes = (bt - at) / 60000;
              if (meters >= 10) movingMinutes += minutes; else waitingMinutes += minutes;
            }
          }

          // Include the final segment up to currentLocation for time classification only
          const last = points.length ? points[points.length - 1] : null;
          if (last && last.timestamp) {
            const lastTs = new Date(last.timestamp).getTime();
            if (Number.isFinite(lastTs) && now.getTime() > lastTs) {
              const metersToNow = geolib.getDistance(
                { latitude: Number(last.lat), longitude: Number(last.lng) },
                { latitude: Number(currentLocation.latitude), longitude: Number(currentLocation.longitude) }
              );
              const minutes = (now.getTime() - lastTs) / 60000;
              if (Number.isFinite(metersToNow)) {
                if (metersToNow >= 10) movingMinutes += minutes; else waitingMinutes += minutes;
              } else {
                waitingMinutes += minutes;
              }
            }
          }
        }
      } catch (err) {
        try { logger.warn('[PricingService] TripHistory unavailable, falling back to pickup→current', { bookingId, error: err && err.message }); } catch (_) {}
      }
    }

    if (!Number.isFinite(distanceTraveled) || distanceTraveled <= 0) {
      // Fallback: straight-line pickup → current
      distanceTraveled = geolib.getDistance(
        { latitude: booking.pickup.latitude, longitude: booking.pickup.longitude },
        { latitude: currentLocation.latitude, longitude: currentLocation.longitude }
      ) / 1000;
    }

    logger.info('[PricingService] Distance calculated:', {
      bookingId,
      distanceTraveled: Math.round(distanceTraveled * 100) / 100
    });

    const referenceStart = booking.startedAt || booking.acceptedAt || booking.createdAt;
    let elapsedMinutes = 0;
    if (referenceStart) {
      try {
        const startTs = new Date(referenceStart).getTime();
        if (Number.isFinite(startTs)) {
          elapsedMinutes = Math.max(0, (Date.now() - startTs) / 60000);
        }
      } catch (_) {}
    }

  const baseFare = Number(pricing.baseFare || 0);
  const perKm = Number(pricing.perKm || 0);
  const perMinute = Number(pricing.perMinute || 0);
  const waitingPerMinute = Number(pricing.waitingPerMinute || 0);
    const surgeMultiplier = Number(pricing.surgeMultiplier || 1) > 0 ? Number(pricing.surgeMultiplier || 1) : 1;
    const minimumFare = Number(pricing.minimumFare || 0);
    const maximumFare = Number(pricing.maximumFare || 0);

    // Derive moving/ waiting minutes from trip points when available; otherwise fallback to elapsed
    if (!(movingMinutes > 0 || waitingMinutes > 0)) {
      movingMinutes = elapsedMinutes;
      waitingMinutes = elapsedMinutes;
    }

    const distanceCostRaw = distanceTraveled * perKm;
    const timeCostRaw = movingMinutes * perMinute;
    const waitingCostRaw = waitingMinutes * waitingPerMinute;

    let currentFare = (baseFare + distanceCostRaw + timeCostRaw + waitingCostRaw) * surgeMultiplier;
    if (minimumFare > 0 && currentFare < minimumFare) {
      currentFare = minimumFare;
    }
    if (maximumFare > 0 && currentFare > maximumFare) {
      currentFare = maximumFare;
    }

    currentFare = Number(currentFare.toFixed(2));

    // Calculate live fare based on distance traveled
    const fareBreakdown = {
      base: Number(baseFare.toFixed(2)),
      distanceCost: Number(distanceCostRaw.toFixed(2)),
      timeCost: Number(timeCostRaw.toFixed(2)),
      waitingCost: Number(waitingCostRaw.toFixed(2)),
      surgeMultiplier,
    };

    const finalFare = currentFare;

    logger.info('[PricingService] Fare calculation completed:', {
      bookingId,
      fareBreakdown: {
        base: fareBreakdown.base,
        distanceCost: Math.round(fareBreakdown.distanceCost * 100) / 100,
        surgeMultiplier: fareBreakdown.surgeMultiplier
      },
      currentFare: Math.round(currentFare * 100) / 100,
      finalFare: Math.round(finalFare * 100) / 100,
      minimumFareApplied: finalFare > currentFare
    });

  const result = {
      bookingId: String(booking._id),
      driverId: booking.driverId ? String(booking.driverId) : undefined,
      passengerId: booking.passengerId ? String(booking.passengerId) : undefined,
      currentLocation,
      distanceTraveled: Math.round(distanceTraveled * 100) / 100, // Round to 2 decimal places
      currentFare: finalFare,
      fareBreakdown: {
        ...fareBreakdown
      },
      elapsedMinutes: Number(elapsedMinutes.toFixed(2)),
      movingMinutes: Number(movingMinutes.toFixed(2)),
      waitingMinutes: Number(waitingMinutes.toFixed(2)),
      updatedAt: new Date()
    };

    // Broadcast pricing update to relevant rooms and legacy channels
    logger.info('[PricingService] Broadcasting pricing update:', {
      bookingId,
      targetedRooms: {
        booking: `booking:${String(booking._id)}`,
        driver: booking.driverId ? `driver:${String(booking.driverId)}` : null,
        passenger: booking.passengerId ? `passenger:${String(booking.passengerId)}` : null
      },
      result: {
        distanceTraveled: result.distanceTraveled,
        currentFare: result.currentFare,
        updatedAt: result.updatedAt
      }
    });

    emitBookingTargets(
      {
        bookingId: booking._id,
        driverId: booking.driverId ? String(booking.driverId) : undefined,
        passengerId: booking.passengerId ? String(booking.passengerId) : undefined
      },
      'pricing:update',
      result,
      { includeOps: true }
    );

  try {
    booking.fareEstimated = result.currentFare;
    booking.distanceKm = result.distanceTraveled;
    await booking.save();
  } catch (_) {}

    logger.info('[PricingService] Live pricing calculation completed successfully:', {
      bookingId: String(booking._id),
      driverId: booking.driverId,
      distanceTraveled: result.distanceTraveled,
      currentFare: result.currentFare,
      processingTimeMs: Date.now() - new Date(result.updatedAt).getTime()
    });

    try {
      metrics.increment('pricing.live_calculation_success', 1, {
        vehicleType: booking.vehicleType || 'unknown'
      });
      metrics.timing('pricing.live_calculation_ms', Date.now() - startedAt, {
        vehicleType: booking.vehicleType || 'unknown'
      });
    } catch (_) {}

    return result;
  } catch (error) {
    logger.error('[PricingService] Error calculating live pricing:', {
      bookingId,
      currentLocation,
      error: error.message,
      stack: error.stack,
      timestamp: new Date().toISOString()
    });
    try {
      metrics.increment('pricing.live_calculation_error', 1, {
        reason: error && error.message ? error.message : 'unknown'
      });
    } catch (_) {}
    throw error;
  }
}

module.exports = { 
  recalcForBooking,
  calculateLivePricing
};

